package bank;

import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
public class Ex2 extends HttpServlet
{
	Connection con;
	Statement st;
	ResultSet rs;
	int s1;
	String s2,s3,s4;
	ServletConfig config;

	public void init(ServletConfig config) throws ServletException
	{
		this.config=config;
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");  
			//System.out.println("success");
con= DriverManager.getConnection
("Jdbc:Oracle:thin:@localhost:1521:XE","system","909090");
		         		}
		catch(Exception e)
		{
			System.out.println("\nError :"+e);
			e.printStackTrace();
		}
	}

	public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
    	{
		String u = req.getParameter("username");
		int uid = Integer.parseInt(u);
		String password = req.getParameter("password");
		int flag=0;
		//ServletContext sc = config.getServletContext();
		String z = "sannalalikhitha@gmail.com";
		try
		{
			res.setContentType("text/html");
			PrintWriter writer = res.getWriter();
			writer.println("<html>");
			writer.println("<head><title>Simple Servlet Program Demo</title></head>");
			writer.println("<body>");
			writer.println("For any problem with the application, mail to : "+z);
			st=con.createStatement();
			rs=st.executeQuery("Select * from bankuser where userid="+uid);
			if(!rs.next())
			{
				writer.println("<h1>The user "+ u + "does not exist</h1>");
				flag=1;
			}
			else
			{
				s1=rs.getInt(1);
				s2=rs.getString(2);
				s3=rs.getString(3);
				s4=rs.getString(4);
				if(s4.equals("A"))
				{
					if(s2.equals(password))
						writer.println("<h1> The user is authenticated </h1>");
					else
					{
						writer.println("<h1> Authentication failed due to incorrect password</h1>");
						flag=1;
					}
				}
				else
				{
					flag=1;
					writer.println("The user account is disabled");
				}

			}
			if(flag==0)
			{
				HttpSession session= req.getSession();
				session.setAttribute("userid", u);
writer.println("Thank you, "+u+". You are now logged into the system.");
				if(s3.equals("A"))
					res.sendRedirect("managerform.html" );
				else{
					if(s3.equals("S"))
						res.sendRedirect("Stafform.html");
					else
						res.sendRedirect("custform.html");
				}
			}
			writer.println("</body></html>");
			writer.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
    	}
}

