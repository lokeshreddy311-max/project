package bank;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

import java.io.*;
import java.sql.*;
public class AccountOperation
{
	Connection con;
	Statement st;
	PreparedStatement pstmt;
	ResultSet rs,rs1,rs2;
	int x, bal, currbal;
	String insertqry="insert into BankUserTransaction values(?, ?, ?, sysdate, ?, ?)";
	public AccountOperation()
	{
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");  
			//System.out.println("success");
con= DriverManager.getConnection
("Jdbc:Oracle:thin:@localhost:1521:XE","system","909090");		}
		catch(Exception e)
		{
			System.out.println("\nError :"+e); 
			e.printStackTrace();
		}
	}
	public boolean depositWithdraw(int accnum, String tran_type, String tran_desc, int amt)
    	{
		int flag=0;
		try
		
		{
			pstmt=con.prepareStatement(insertqry);
			pstmt.setInt(1, accnum );
			pstmt.setString(2, tran_desc );
			pstmt.setString(3, tran_type);
			pstmt.setInt(4, amt);
			st=con.createStatement();
			rs=st.executeQuery("Select current_balance from account_info_table where accno="+accnum);
			if(rs.next())
				bal=rs.getInt(1);
			if (tran_type=="C")
				currbal=bal+amt;
			else
				currbal=bal-amt;
			pstmt.setInt(5, currbal);
			pstmt.executeUpdate();
			pstmt.close();

			pstmt=con.prepareStatement("update account_info_table set current_balance=? where accno="+accnum);
			pstmt.setInt(1, currbal);
			pstmt.executeUpdate();
			return true;			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return false;
		}
    	}
}
