package bank;
import java.sql.*;

class MakeConnection7
{
        Connection con;
        Statement stmt;
        int  i;
        MakeConnection7() 
	{
        	try
		{
        		Class.forName("oracle.jdbc.driver.OracleDriver");  
    			//System.out.println("success");
    con= DriverManager.getConnection
    ("Jdbc:Oracle:thin:@localhost:1521:XE","system","909090"); 	stmt = con.createStatement();
                  	i  = stmt.executeUpdate
                ("create table BankUserTransaction(accno number(16),"
               + " trans_desc varchar2(40),tran_type varchar2(1),"
               + " tran_date date, amount number(15,2), closing_balance number(15,2))");
                  	System.out.println(" Transaction Table Created");
              	}  
		catch(Exception e) 
		{
			System.out.println("Table Already Exists\n\n"+e);
		}
	}
}             

class CreateTransactionTable
{
	public  static void   main(String args[]) 
	{
        	new MakeConnection7();
        }
}
