package bank;

import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

import java.io.*;
import java.sql.*;

public class Ex4 extends HttpServlet
{
	int bal, amt;
	String accnum, tran_type, tran_desc;
	int accno;
	AccountOperation ao;
	boolean flag;

	public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
	{
		ao=new AccountOperation();
		HttpSession session=req.getSession();
		ServletContext sc = getServletConfig().getServletContext();
		String z = sc.getInitParameter("admin-email");

		String s1=req.getParameter("depositamount");
		String s2=req.getParameter("withdrawamount");
		accnum=(String)session.getAttribute("accountno");
		accno=Integer.parseInt(accnum);
		if (s1!=null)
		{
			tran_type="C";
			tran_desc="Deposit";
			amt=Integer.parseInt(s1);
		}
		else
		if(s2!=null)
		{
			tran_type="D";
			tran_desc="Withdrawal";
			amt=Integer.parseInt(s2);
		}

		flag=ao.depositWithdraw(accno, tran_type, tran_desc, amt);

		res.setContentType("text/html");
		PrintWriter writer = res.getWriter();
		writer.println("<html>");
		writer.println("<head><title>Servlet Program for Updation</title></head>");
		writer.println("<body bgcolor='pink'>");
		writer.println("For any problem with the application, mail to : "+z);
		if (flag==true)
			writer.println("<h1>The details have been updated successfully..!</h1>");
		else
			writer.println("<h1>The details have not been updated due to some operation problem..!</h1>");
	}
}

