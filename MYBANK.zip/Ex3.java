package bank;

import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

import java.io.*;
import java.sql.*;

public class Ex3 extends HttpServlet
{
	Connection con;
	Statement st;
	ResultSet rs;
	int x, bal;
	int accnum;
	String acc, type, acctype;
	ServletConfig config;

	public void init(ServletConfig config) throws ServletException
	{
		this.config=config;
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");  
			//System.out.println("success");
con= DriverManager.getConnection
("Jdbc:Oracle:thin:@localhost:1521:XE","system","909090");
}
		catch(Exception e)
		{System.out.println("\nError :"+e); e.printStackTrace();}
	}

	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
    	{
		acc = req.getParameter("AccountNumber");
		accnum = Integer.parseInt(acc);
		HttpSession session= req.getSession();
		session.setAttribute("accountno", acc);
		int flag=0;
		ServletContext sc = config.getServletContext();
		String z = sc.getInitParameter("admin-email");
		String y = config.getInitParameter("msg");
		try
		
		{
			res.setContentType("text/html");
			PrintWriter writer = res.getWriter();
			writer.println("<html>");
			writer.println("<head><title>Simple Servlet Program Demo</title></head>");
			writer.println("<body>");
			writer.println(y);
			st=con.createStatement();
			rs=st.executeQuery("Select acc_type, current_balance from account_info_table where accno="+accnum);
			if(!rs.next())
			{
				writer.println("<h1>The account "+ accnum + "does not exist</h1>");
				flag=1;
			}
			else
			{
				type=rs.getString(1);
				bal=rs.getInt(2);
				if(type.equals("S"))
					acctype="Savings";
				else
					acctype="Current";

				writer.println("<body bgcolor ='cyan'></body>");

				writer.println("<table BORDER=' ' WIDTH='50%' CELLSPACING='2' CELLPADDING='2' align='center'>");
				writer.println("<th><tr><td bgcolor='blue'> Account Number </td>");
				writer.println("<td bgcolor='blue'>  Account Type </td>");
				writer.println("<td bgcolor='blue'>Amount Balance </td></tr></th><br>");

				writer.println("<tr><td bgcolor='white'>"+accnum+" </td> <td bgcolor='white'>"+acctype+" </td> <td bgcolor='white'>" +bal+" </td></tr><br></table><BR><BR><BR><BR>");
				writer.println("<CENTER><input type='button' name='Deposit' value='Deposit'  onClick=window.open('Amount-entry-deposit.html')>");
				writer.println("<input type='button' name='Withdrawal' value='Withdrawal'  onClick=window.open('Amount-entry-withdraw.html')><br>");
			}
			writer.println("</body></html>");
			writer.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
    	}
}

