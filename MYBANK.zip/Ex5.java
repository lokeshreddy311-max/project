package bank;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

import java.io.*;
import java.sql.*;

public class Ex5 extends HttpServlet
{
	Connection con;
	Statement st;
	ResultSet rs;
	int accnum;
	String acc, uid;

	public void init(ServletConfig config) throws ServletException
	{
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");  
			//System.out.println("success");
con= DriverManager.getConnection
("Jdbc:Oracle:thin:@localhost:1521:XE","system","909090");
		}
		catch(Exception e)
		{
			System.out.println("\nError :"+e); 
			e.printStackTrace();
		}
	}

	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
    	{
		acc = req.getParameter("AccountNumber");
		accnum = Integer.parseInt(acc);
		HttpSession session= req.getSession();
		uid = (String)session.getAttribute("userid");
		try
		
		{
			st = con.createStatement();
			rs = st.executeQuery("Select * from account_info_table where userid = "+uid+" and accno="+accnum);
			if(!rs.next())
				res.sendRedirect("custinvalid.html");	
			else
			{
				RequestDispatcher view = req.getRequestDispatcher("Ex6");
				view.forward(req, res);	
			}
		}
		catch(SQLException e)
		{
			System.out.println(e);
		}
   	}
}

